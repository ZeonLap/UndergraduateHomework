`main.py`：使用`argparse`模块来选择参数

`test_cnn.sh`：测试用的脚本。