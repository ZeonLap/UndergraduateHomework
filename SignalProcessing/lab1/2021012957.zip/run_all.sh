# square
python exp1.py --signal_name square --N_Fourier 2
python exp1.py --signal_name square --N_Fourier 4
python exp1.py --signal_name square --N_Fourier 8
python exp1.py --signal_name square --N_Fourier 16
python exp1.py --signal_name square --N_Fourier 32
python exp1.py --signal_name square --N_Fourier 64
python exp1.py --signal_name square --N_Fourier 128
# semicircle
python exp1.py --signal_name semicircle --N_Fourier 2
python exp1.py --signal_name semicircle --N_Fourier 4
python exp1.py --signal_name semicircle --N_Fourier 8
python exp1.py --signal_name semicircle --N_Fourier 16
python exp1.py --signal_name semicircle --N_Fourier 32
python exp1.py --signal_name semicircle --N_Fourier 64
python exp1.py --signal_name semicircle --N_Fourier 128